// SaberQuest — AI Services
import { LANGUAGES, DIFFICULTY_LABELS, WORLDS, PHASES_DATA } from '@/data/constants';

// --- AI Helper ---
export async function callAI(systemPrompt, userMessage) {
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      }),
    });
    const data = await response.json();
    return data.content?.[0]?.text || "";
  } catch (e) {
    return null;
  }
}

export async function generateExercise(world, level, lang, difficulty, retryHint = 0) {
  const diffLabel = DIFFICULTY_LABELS[lang]?.[difficulty] || difficulty;
  const worldName = WORLDS[world]?.name[lang] || world;
  const phaseInfo = PHASES_DATA[world]?.[lang]?.[level - 1];
  const uniqueTag = retryHint > 0 ? ` This is attempt #${retryHint + 1}, so generate a COMPLETELY DIFFERENT question from any previous one. Use different numbers, words, or scenarios.` : "";

  // Detailed topic constraints per world/level to ensure phase-accurate exercises
  const PHASE_TOPICS = {
    math: {
      1: "ONLY addition with numbers 1-10. Example: 3+4, 2+8. Do NOT use subtraction, multiplication or division.",
      2: "ONLY subtraction with numbers 1-20. Example: 15-7, 12-5. Do NOT use addition, multiplication or division.",
      3: "ONLY multiplication using times tables 2 through 5. Example: 3x4, 5x2. Do NOT use addition, subtraction or division.",
      4: "ONLY simple division with small numbers. Example: 12÷3, 20÷4. Do NOT use addition, subtraction or multiplication.",
      5: "Mixed operations (addition, subtraction, multiplication AND division). Use word problems combining multiple operations.",
    },
    portuguese: {
      1: "ONLY about vowels (a,e,i,o,u) and consonants. Ask to identify, classify or differentiate vowels from consonants in words.",
      2: "ONLY about syllables: splitting words into syllables, counting syllables, or forming words from syllables.",
      3: "ONLY about completing/spelling words correctly: fill in missing letters, find the correct spelling, or unscramble letters.",
      4: "ONLY about sentence structure: ordering words to form correct sentences, identifying subject/verb, or punctuation.",
      5: "ONLY about creative sentence building: complete a sentence, choose the best word to fill a gap, or interpret short texts.",
    },
    science: {
      1: "ONLY about animals: classification (mammals, birds, reptiles, fish, insects), habitats, characteristics, or animal behaviors.",
      2: "ONLY about Planet Earth: water cycle, air/atmosphere, soil types, weather, or natural resources.",
      3: "ONLY about the human body: organs (heart, lungs, brain), the 5 senses, bones, or how the body works.",
      4: "ONLY about plants: photosynthesis, parts of a plant (roots, stem, leaves, flower), plant growth, or seeds.",
      5: "ONLY about science experiments and scientific method: observations, hypotheses, simple experiments, or cause-and-effect.",
    },
    geography: {
      1: "ONLY about the local neighborhood/community: types of places (school, hospital, park), directions, or maps of nearby areas.",
      2: "ONLY about Brazilian states: capitals, regions (Norte, Nordeste, Sul, etc.), or geographic features of Brazil.",
      3: "ONLY about continents and oceans: names, locations, sizes, or characteristics of the 7 continents and 5 oceans.",
      4: "ONLY about world cultures: traditions, foods, clothing, languages, or customs of different countries/peoples.",
      5: "ONLY about global geography challenge: mix of countries, capitals, flags, landmarks, or geographic records (tallest, longest, etc.).",
    },
    languages: {
      1: "ONLY basic greetings and introductions in English and Spanish: hello, goodbye, please, thank you, my name is.",
      2: "ONLY colors and numbers (1-20) in English and Spanish: vocabulary, matching, or translation exercises.",
      3: "ONLY animal names in English, Spanish, and Portuguese: translate animal names between the three languages.",
      4: "ONLY daily phrases and common expressions in English and Spanish: asking for things, telling time, days of the week.",
      5: "ONLY a trilingual challenge mixing vocabulary from all previous phases: translate or match words/phrases across PT/EN/ES.",
    },
  };

  const topicConstraint = PHASE_TOPICS[world]?.[level] || "";

  const systemPrompt = `You are a loving, patient teacher for children aged 6-10. You MUST respond ONLY in valid JSON, no markdown, no backticks. Generate a fun, age-appropriate exercise. The difficulty is: ${diffLabel}. All text must be in ${LANGUAGES[lang].label}.${uniqueTag}

CRITICAL RULES FOR THE EXPLANATION FIELD:
- You are explaining to a CHILD who got the answer WRONG, so be extra gentle and didactic.
- Break down the reasoning step by step, as if teaching for the first time.
- Use everyday examples the child can relate to (toys, fruits, animals, school, family). IMPORTANT: Never use references to body parts like fingers, hands, or chin as teaching tools — be inclusive of all children.
- Show the reasoning process, not just the answer. For math: show each step. For language: explain the rule. For science: connect to something they can see or touch.
- Use encouraging language: "Let's think together...", "Imagine that...", "It's like when...".
- Keep sentences short and simple. Avoid technical jargon.
- The explanation should be 2-4 sentences long, never just one sentence.`;

  const userMessage = `Generate an exercise for: World="${worldName}", Phase="${phaseInfo?.title}", Topic="${phaseInfo?.desc}", Difficulty="${diffLabel}", Language="${LANGUAGES[lang].label}".

CRITICAL TOPIC CONSTRAINT — you MUST follow this strictly:
${topicConstraint}

Return ONLY this JSON structure:
{"question":"the question text","options":["option A","option B","option C","option D"],"correctIndex":0,"hint":"a helpful hint","explanation":"step-by-step explanation that teaches the child WHY the answer is correct, using everyday examples and gentle language"}`;

  const result = await callAI(systemPrompt, userMessage);
  if (!result) return null;
  try {
    const cleaned = result.replace(/```json\s*/g, "").replace(/```/g, "").trim();
    return JSON.parse(cleaned);
  } catch {
    return null;
  }
}

export async function chatWithZuki(message, lang, context) {
  const langName = LANGUAGES[lang].label;
  const systemPrompt = `You are Zuki, a friendly and wise owl mascot for a children's educational app called SaberQuest. You help children aged 6-10 learn. You are always encouraging, patient, and fun. Use simple language appropriate for children. Always respond in ${langName}. Use emojis occasionally to be fun. Keep responses short (2-3 sentences max). Never use inappropriate language. The child is currently in: ${context}. If they ask about a subject, give a helpful and simple explanation.`;

  return await callAI(systemPrompt, message);
}

