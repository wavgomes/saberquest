import React from "react";

export function WorldCard({ world, lang, onClick, visited }) {
  return (
    <button onClick={onClick}
      className={`group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br ${world.gradient} text-white shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 text-left h-full w-full flex flex-col justify-start`}>
      <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-6 translate-x-6" />
      <div className="absolute bottom-0 left-0 w-16 h-16 bg-white/10 rounded-full translate-y-4 -translate-x-4" />
      <span className="text-4xl mb-2 block drop-shadow-md">{world.icon}</span>
      <h3 className="text-lg font-extrabold tracking-tight mb-1">{world.name[lang]}</h3>
      <p className="text-sm text-white/80 mt-auto">{world.desc[lang]}</p>
      {visited && <span className="absolute top-3 right-3 text-xs bg-white/30 rounded-full px-2 py-0.5">✓</span>}
    </button>
  );
}
