import { useState, useEffect, useRef } from "react";
import { MASCOT_MESSAGES, UI_TEXT } from "@/data/constants";
import { chatWithZuki } from "@/services/ai";
import { Mascot } from "./Mascot";

export function ZukiChat({ lang, context, onClose }) {
  const [messages, setMessages] = useState([{ from: "zuki", text: MASCOT_MESSAGES[lang].welcome }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEnd = useRef(null);
  const t = UI_TEXT[lang];

  useEffect(() => { messagesEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages((m) => [...m, { from: "user", text: userMsg }]);
    setLoading(true);
    const reply = await chatWithZuki(userMsg, lang, context);
    setMessages((m) => [...m, { from: "zuki", text: reply || MASCOT_MESSAGES[lang].welcome }]);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end sm:items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}
        style={{ animation: "slideUp 0.3s ease-out" }}>
        <div className="bg-gradient-to-r from-amber-400 to-yellow-400 px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mascot size="sm" animate={false} />
            <span className="font-bold text-white text-lg">Zuki</span>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white text-2xl font-bold">&times;</button>
        </div>
        <div className="h-72 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-amber-50 to-white">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.from === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${msg.from === "user" ? "bg-indigo-500 text-white rounded-br-md" : "bg-white shadow-md text-gray-700 rounded-bl-md border border-amber-100"}`}>
                {msg.text}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-white shadow-md px-4 py-2.5 rounded-2xl rounded-bl-md text-sm text-gray-400 border border-amber-100">
                <span className="animate-pulse">{t.loading}</span>
              </div>
            </div>
          )}
          <div ref={messagesEnd} />
        </div>
        <div className="p-3 border-t border-gray-100 flex gap-2">
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder={t.askZuki} className="flex-1 px-4 py-2.5 rounded-full bg-gray-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-300" />
          <button onClick={send} disabled={loading}
            className="bg-gradient-to-r from-amber-400 to-yellow-400 text-white px-5 py-2.5 rounded-full font-bold text-sm hover:shadow-lg transition-all disabled:opacity-50">
            {t.send}
          </button>
        </div>
      </div>
    </div>
  );
}
