import React from "react";

export function PhaseNode({ phase, status, onClick, index }) {
  const colors = { locked: "bg-gray-300 text-gray-400", available: "bg-gradient-to-br from-indigo-400 to-purple-500 text-white shadow-lg hover:scale-110 cursor-pointer", completed: "bg-gradient-to-br from-green-400 to-emerald-500 text-white shadow-lg" };
  return (
    <div className="flex flex-col items-center">
      <button onClick={status !== "locked" ? onClick : undefined} disabled={status === "locked"}
        className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold ${colors[status]} transition-all duration-300 border-4 border-white`}>
        {status === "completed" ? "⭐" : status === "locked" ? "🔒" : phase.level}
      </button>
      <span className="text-xs font-semibold mt-1.5 text-center max-w-20 leading-tight">{phase.title}</span>
      <span className="text-[10px] text-gray-400">{phase.desc}</span>
    </div>
  );
}
