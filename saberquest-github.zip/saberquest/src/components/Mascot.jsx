import React from "react";

export function Mascot({ size = "lg", mood = "happy", animate = true }) {
  const sizes = { sm: "w-10 h-10 text-xl", md: "w-14 h-14 text-3xl", lg: "w-20 h-20 text-5xl", xl: "w-28 h-28 text-7xl" };
  const faces = { happy: "🦉", thinking: "🦉", excited: "🦉", sad: "🦉" };
  return (
    <div className={`${sizes[size]} rounded-full bg-gradient-to-br from-yellow-300 to-amber-400 flex items-center justify-center shadow-lg ${animate ? "animate-bounce" : ""}`}
      style={{ animationDuration: "2s" }}>
      <span role="img" aria-label="Zuki the owl">{faces[mood]}</span>
    </div>
  );
}
