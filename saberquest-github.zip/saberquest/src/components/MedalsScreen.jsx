import React from "react";
import { MEDALS, UI_TEXT } from "@/data/constants";
import { MedalBadge } from "./MedalBadge";

export function MedalsScreen({ stats, lang }) {
  const t = UI_TEXT[lang];
  const unlocked = MEDALS.filter((m) => m.condition(stats));
  const locked = MEDALS.filter((m) => !m.condition(stats));

  return (
    <div className="max-w-lg mx-auto px-4">
      <div className="text-center mb-6">
        <span className="text-5xl mb-2 block">🏅</span>
        <h2 className="text-2xl font-extrabold text-gray-800">{t.medals}</h2>
        <p className="text-sm text-gray-500">{unlocked.length}/{MEDALS.length}</p>
      </div>

      <div className="bg-white rounded-3xl shadow-xl p-5 mb-4">
        <div className="flex items-center gap-4 mb-4 p-3 bg-indigo-50 rounded-2xl">
          <div className="text-center flex-1">
            <p className="text-2xl font-black text-indigo-600">{stats.totalScore}</p>
            <p className="text-[10px] text-gray-500 font-semibold uppercase">{t.totalScore}</p>
          </div>
          <div className="w-px h-10 bg-indigo-200" />
          <div className="text-center flex-1">
            <p className="text-2xl font-black text-green-600">{stats.totalCorrect}</p>
            <p className="text-[10px] text-gray-500 font-semibold uppercase">{t.exercisesCompleted}</p>
          </div>
          <div className="w-px h-10 bg-indigo-200" />
          <div className="text-center flex-1">
            <p className="text-2xl font-black text-amber-500">{stats.streak}🔥</p>
            <p className="text-[10px] text-gray-500 font-semibold uppercase">{t.currentStreak}</p>
          </div>
        </div>

        {unlocked.length > 0 && (
          <>
            <h3 className="text-sm font-bold text-green-600 mb-2">{t.unlockedMedals}</h3>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {unlocked.map((m) => <MedalBadge key={m.id} medal={m} unlocked lang={lang} />)}
            </div>
          </>
        )}
        {locked.length > 0 && (
          <>
            <h3 className="text-sm font-bold text-gray-400 mb-2">{t.lockedMedals}</h3>
            <div className="grid grid-cols-3 gap-2">
              {locked.map((m) => <MedalBadge key={m.id} medal={m} unlocked={false} lang={lang} />)}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// --- Main App ---
