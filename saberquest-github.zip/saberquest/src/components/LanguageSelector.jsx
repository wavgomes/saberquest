import React from "react";
import { LANGUAGES } from "@/data/constants";

export function LanguageSelector({ lang, setLang }) {
  return (
    <div className="flex items-center gap-1 bg-white/80 backdrop-blur rounded-full px-2 py-1 shadow-md">
      {Object.entries(LANGUAGES).map(([key, { flag }]) => (
        <button key={key} onClick={() => setLang(key)}
          className={`text-lg px-2 py-1 rounded-full transition-all duration-200 ${lang === key ? "bg-indigo-500 scale-110 shadow-md" : "hover:bg-gray-100"}`}>
          {flag}
        </button>
      ))}
    </div>
  );
}
