import React from "react";

export function MedalBadge({ medal, unlocked, lang }) {
  return (
    <div className={`relative flex flex-col items-center p-3 rounded-2xl transition-all duration-300 ${unlocked ? "bg-gradient-to-br from-yellow-50 to-amber-100 shadow-md scale-100" : "bg-gray-100 opacity-50 scale-95"}`}>
      <span className={`text-3xl mb-1 ${unlocked ? "" : "grayscale"}`}>{medal.icon}</span>
      <span className="text-xs font-bold text-center leading-tight">{medal.name[lang]}</span>
      <span className="text-[10px] text-gray-500 text-center mt-0.5">{medal.desc[lang]}</span>
      {unlocked && (
        <div className="absolute -top-1 -right-1 w-5 h-5 bg-green-400 rounded-full flex items-center justify-center shadow">
          <span className="text-white text-[10px]">✓</span>
        </div>
      )}
    </div>
  );
}
