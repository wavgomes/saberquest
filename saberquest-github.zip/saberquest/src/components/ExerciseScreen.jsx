import { useState, useEffect } from "react";
import { WORLDS, PHASES_DATA, DIFFICULTY_LABELS, UI_TEXT, LANGUAGES } from "@/data/constants";
import { generateExercise } from "@/services/ai";
import { generateFallbackExercise } from "@/data/fallbackExercises";
import { Mascot } from "./Mascot";

export function ExerciseScreen({ world, level, lang, difficulty, onComplete, onBack }) {
  const [exercise, setExercise] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [result, setResult] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const t = UI_TEXT[lang];

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setSelected(null);
    setResult(null);
    generateExercise(world, level, lang, difficulty, retryCount).then((ex) => {
      if (cancelled) return;
      setExercise(ex || generateFallbackExercise(world, level, lang));
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [world, level, lang, difficulty, retryCount]);

  const check = () => {
    if (selected === null) return;
    const correct = selected === exercise.correctIndex;
    setResult({ correct, explanation: exercise.explanation });
    setAttempts((a) => a + 1);
  };

  const handleRetry = () => {
    setRetryCount((c) => c + 1);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <Mascot size="xl" mood="thinking" />
        <p className="text-lg font-bold text-indigo-600 animate-pulse">{t.generating}</p>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-4">
      <div className="text-center mb-6">
        <span className="text-5xl mb-2 block">{WORLDS[world]?.icon}</span>
        <h2 className="text-xl font-extrabold text-gray-800">
          {PHASES_DATA[world]?.[lang]?.[level - 1]?.title}
        </h2>
        <span className="text-xs bg-indigo-100 text-indigo-600 px-3 py-1 rounded-full font-semibold">
          {t.level} {level} · {DIFFICULTY_LABELS[lang][difficulty]}
        </span>
      </div>

      <div className="bg-white rounded-3xl shadow-xl p-6 mb-4">
        <div className="flex items-start gap-3 mb-5">
          <Mascot size="sm" animate={false} />
          <div className="bg-amber-50 rounded-2xl rounded-tl-md p-4 flex-1 border border-amber-100">
            <p className="text-gray-800 font-semibold text-base">{exercise.question}</p>
            {exercise.hint && !result && (
              <p className="text-xs text-amber-600 mt-2">💡 {exercise.hint}</p>
            )}
          </div>
        </div>

        <div className="space-y-2.5">
          {exercise.options.map((opt, i) => {
            let optStyle = "bg-gray-50 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50";
            if (result) {
              if (i === exercise.correctIndex) optStyle = "bg-green-50 border-green-400 ring-2 ring-green-300";
              else if (i === selected && !result.correct) optStyle = "bg-red-50 border-red-400";
              else optStyle = "bg-gray-50 border-gray-200 opacity-50";
            } else if (selected === i) {
              optStyle = "bg-indigo-100 border-indigo-400 ring-2 ring-indigo-300";
            }
            return (
              <button key={i} onClick={() => !result && setSelected(i)}
                className={`w-full text-left px-4 py-3 rounded-xl border-2 transition-all duration-200 font-medium ${optStyle}`}>
                <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-white shadow-sm text-sm font-bold mr-3 border">
                  {String.fromCharCode(65 + i)}
                </span>
                {opt}
              </button>
            );
          })}
        </div>

        {result && (
          <div className={`mt-5 p-4 rounded-2xl ${result.correct ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"}`}>
            <p className={`font-bold text-lg mb-1 ${result.correct ? "text-green-600" : "text-red-500"}`}>
              {result.correct ? `🎉 ${t.correct}` : `😅 ${t.wrong}`}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-semibold">{t.explanation}:</span> {result.explanation}
            </p>
            {!result.correct && (
              <div className="mt-3 pt-3 border-t border-red-100">
                <div className="flex items-center gap-2">
                  <Mascot size="sm" animate={false} />
                  <p className="text-sm text-gray-600 italic">{t.retryEncouragement}</p>
                </div>
              </div>
            )}
            {result.correct && attempts > 1 && (
              <div className="mt-3 pt-3 border-t border-green-100">
                <div className="flex items-center gap-2">
                  <Mascot size="sm" animate={false} />
                  <p className="text-sm text-green-600 italic">{t.persistencePaidOff}</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex gap-3 justify-center">
        {!result ? (
          <button onClick={check} disabled={selected === null}
            className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-8 py-3 rounded-full font-bold text-lg shadow-lg hover:shadow-xl transition-all disabled:opacity-40 disabled:cursor-not-allowed">
            {t.check}
          </button>
        ) : result.correct ? (
          <button onClick={() => onComplete(true)}
            className="bg-gradient-to-r from-green-400 to-emerald-500 text-white px-8 py-3 rounded-full font-bold text-lg shadow-lg hover:shadow-xl transition-all">
            {t.continue} ✨
          </button>
        ) : (
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <button onClick={handleRetry}
              className="bg-gradient-to-r from-amber-400 to-yellow-400 text-white px-8 py-3 rounded-full font-bold text-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2">
              🔄 {t.tryAgain}
            </button>
            <button onClick={() => onComplete(false)}
              className="bg-gray-200 text-gray-600 px-6 py-3 rounded-full font-bold text-sm hover:bg-gray-300 transition-all">
              {t.skipForNow}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
