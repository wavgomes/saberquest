// SaberQuest — Main Application
import { useState, useCallback } from "react";
import { WORLDS, PHASES_DATA, MEDALS, DIFFICULTY_LABELS, UI_TEXT, LANGUAGES } from "@/data/constants";
import { Mascot } from "@/components/Mascot";
import { LanguageSelector } from "@/components/LanguageSelector";
import { WorldCard } from "@/components/WorldCard";
import { PhaseNode } from "@/components/PhaseNode";
import { ExerciseScreen } from "@/components/ExerciseScreen";
import { MedalsScreen } from "@/components/MedalsScreen";
import { ZukiChat } from "@/components/ZukiChat";

export default function SaberQuestApp() {
  const [lang, setLang] = useState("pt");
  const [screen, setScreen] = useState("map");
  const [selectedWorld, setSelectedWorld] = useState(null);
  const [selectedPhase, setSelectedPhase] = useState(null);
  const [showChat, setShowChat] = useState(false);
  const [difficulty, setDifficulty] = useState("easy");
  const [newMedal, setNewMedal] = useState(null);

  const [stats, setStats] = useState({
    totalScore: 0,
    totalCorrect: 0,
    completedLevels: 0,
    streak: 0,
    worldsVisited: 0,
    languagesUsed: 1,
    completedInOtherLang: false,
    worldCompletions: {},
    visitedWorlds: new Set(),
    usedLanguages: new Set(["pt"]),
    completedPhases: {},
  });

  const t = UI_TEXT[lang];

  const checkMedals = useCallback((newStats) => {
    const prevUnlocked = MEDALS.filter((m) => m.condition(stats)).map((m) => m.id);
    const nowUnlocked = MEDALS.filter((m) => m.condition(newStats)).map((m) => m.id);
    const fresh = nowUnlocked.find((id) => !prevUnlocked.includes(id));
    if (fresh) {
      setNewMedal(MEDALS.find((m) => m.id === fresh));
      setTimeout(() => setNewMedal(null), 3000);
    }
  }, [stats]);

  const visitWorld = (worldId) => {
    const newVisited = new Set(stats.visitedWorlds);
    newVisited.add(worldId);
    const newStats = { ...stats, visitedWorlds: newVisited, worldsVisited: newVisited.size };
    checkMedals(newStats);
    setStats(newStats);
    setSelectedWorld(worldId);
    setScreen("phases");
  };

  const handleExerciseComplete = (correct) => {
    const newUsedLangs = new Set(stats.usedLanguages);
    newUsedLangs.add(lang);
    const worldComps = { ...stats.worldCompletions };
    const completedPhases = { ...stats.completedPhases };
    const phaseKey = `${selectedWorld}-${selectedPhase}`;
    let newCompletedLevels = stats.completedLevels;

    if (correct && !completedPhases[phaseKey]) {
      completedPhases[phaseKey] = true;
      newCompletedLevels += 1;
      worldComps[selectedWorld] = (worldComps[selectedWorld] || 0) + 1;
    }

    const newStats = {
      ...stats,
      totalScore: stats.totalScore + (correct ? (difficulty === "hard" ? 30 : difficulty === "medium" ? 20 : 10) : 0),
      totalCorrect: stats.totalCorrect + (correct ? 1 : 0),
      completedLevels: newCompletedLevels,
      streak: correct ? stats.streak + 1 : 0,
      usedLanguages: newUsedLangs,
      languagesUsed: newUsedLangs.size,
      completedInOtherLang: stats.completedInOtherLang || (correct && lang !== "pt"),
      worldCompletions: worldComps,
      completedPhases,
    };
    checkMedals(newStats);
    setStats(newStats);

    if (correct) {
      const newDiff = difficulty === "easy" ? "medium" : difficulty === "medium" ? "hard" : "hard";
      setDifficulty(newDiff);
    } else if (difficulty !== "easy") {
      const newDiff = difficulty === "hard" ? "medium" : "easy";
      setDifficulty(newDiff);
    }
    setScreen("phases");
  };

  const getPhaseStatus = (worldId, level) => {
    const key = `${worldId}-${level}`;
    if (stats.completedPhases[key]) return "completed";
    if (level === 1) return "available";
    const prevKey = `${worldId}-${level - 1}`;
    return stats.completedPhases[prevKey] ? "available" : "locked";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-100 via-blue-50 to-indigo-100 relative overflow-hidden"
      style={{ fontFamily: "'Nunito', 'Segoe UI', sans-serif" }}>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        @keyframes slideUp { from { transform: translateY(100px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes popIn { 0% { transform: scale(0); opacity: 0; } 50% { transform: scale(1.2); } 100% { transform: scale(1); opacity: 1; } }
        @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
        @keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
        .float-anim { animation: float 3s ease-in-out infinite; }
        .pop-in { animation: popIn 0.4s ease-out; }
        .shimmer { background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent); background-size: 200% 100%; animation: shimmer 2s infinite; }
      `}</style>

      {/* Decorative background elements */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-yellow-200/30 rounded-full blur-3xl" />
      <div className="absolute top-40 right-10 w-40 h-40 bg-pink-200/30 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-1/4 w-48 h-48 bg-blue-200/30 rounded-full blur-3xl" />

      {/* Header */}
      <header className="relative z-10 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {screen !== "map" && (
            <button onClick={() => setScreen(screen === "exercise" ? "phases" : "map")}
              className="bg-white/80 backdrop-blur rounded-full px-3 py-1.5 text-sm font-bold text-gray-600 shadow hover:shadow-md transition-all">
              ← {t.back}
            </button>
          )}
          <div className="flex items-center gap-2">
            <span className="text-2xl">🏰</span>
            <h1 className="text-xl font-black bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text">
              {t.appName}
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setScreen("medals")}
            className="bg-white/80 backdrop-blur rounded-full px-3 py-1.5 text-sm font-bold shadow hover:shadow-md transition-all flex items-center gap-1">
            🏅 <span className="text-indigo-600">{MEDALS.filter(m => m.condition(stats)).length}</span>
          </button>
          <LanguageSelector lang={lang} setLang={(l) => { setLang(l); }} />
        </div>
      </header>

      {/* Score bar */}
      <div className="relative z-10 px-4 mb-4">
        <div className="bg-white/60 backdrop-blur rounded-full px-4 py-2 flex items-center justify-between shadow-sm max-w-lg mx-auto">
          <span className="text-sm font-bold text-indigo-600">⭐ {stats.totalScore} {t.score}</span>
          <span className="text-sm font-bold text-amber-500">🔥 {stats.streak}</span>
          <span className="text-xs font-semibold bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded-full">
            {t.difficulty}: {DIFFICULTY_LABELS[lang][difficulty]}
          </span>
        </div>
      </div>

      {/* Main Content */}
      <main className="relative z-10 pb-24">
        {screen === "map" && (
          <div className="px-4 max-w-lg mx-auto" style={{ animation: "slideUp 0.4s ease-out" }}>
            <div className="text-center mb-6">
              <div className="float-anim inline-block">
                <Mascot size="xl" mood="happy" animate={false} />
              </div>
              <h2 className="text-2xl font-black text-gray-800 mt-3">{t.selectWorld}</h2>
              <p className="text-sm text-gray-500">{t.tagline}</p>
            </div>
            <div className="grid grid-cols-2 gap-3 auto-rows-fr">
              {Object.values(WORLDS).map((w, i) => {
                const isLast = i === Object.values(WORLDS).length - 1;
                const isOdd = Object.values(WORLDS).length % 2 !== 0;
                return (
                  <div key={w.id}
                    className={isLast && isOdd ? "col-span-2 max-w-[50%] mx-auto" : ""}
                    style={{ animationDelay: `${i * 0.08}s`, animation: "slideUp 0.5s ease-out both", minHeight: 160 }}>
                    <WorldCard world={w} lang={lang} onClick={() => visitWorld(w.id)} visited={stats.visitedWorlds.has?.(w.id)} />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {screen === "phases" && selectedWorld && (
          <div className="px-4 max-w-lg mx-auto" style={{ animation: "slideUp 0.4s ease-out" }}>
            <div className="text-center mb-6">
              <span className="text-5xl mb-2 block">{WORLDS[selectedWorld].icon}</span>
              <h2 className="text-2xl font-black text-gray-800">{WORLDS[selectedWorld].name[lang]}</h2>
              <p className="text-sm text-gray-500">{t.phases}</p>
            </div>
            <div className="relative">
              {/* Path line */}
              <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-indigo-200 to-purple-200 -translate-x-1/2 rounded-full" />
              <div className="space-y-6 relative">
                {PHASES_DATA[selectedWorld]?.[lang]?.map((phase, i) => {
                  const status = getPhaseStatus(selectedWorld, phase.level);
                  return (
                    <div key={phase.level}
                      className={`flex ${i % 2 === 0 ? "justify-start pl-4" : "justify-end pr-4"}`}
                      style={{ animation: `slideUp 0.4s ease-out ${i * 0.1}s both` }}>
                      <PhaseNode phase={phase} status={status} index={i}
                        onClick={() => { setSelectedPhase(phase.level); setScreen("exercise"); }} />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {screen === "exercise" && selectedWorld && selectedPhase && (
          <div style={{ animation: "slideUp 0.4s ease-out" }}>
            <ExerciseScreen world={selectedWorld} level={selectedPhase} lang={lang} difficulty={difficulty}
              onComplete={handleExerciseComplete}
              onBack={() => setScreen("phases")} />
          </div>
        )}

        {screen === "medals" && (
          <div style={{ animation: "slideUp 0.4s ease-out" }}>
            <MedalsScreen stats={stats} lang={lang} />
          </div>
        )}
      </main>

      {/* Zuki Chat FAB */}
      <button onClick={() => setShowChat(true)}
        className="fixed bottom-6 right-6 z-40 bg-gradient-to-r from-amber-400 to-yellow-400 text-white rounded-full px-5 py-3 shadow-xl hover:shadow-2xl transition-all hover:scale-105 flex items-center gap-2 font-bold">
        <Mascot size="sm" animate={false} />
        <span className="text-sm">{t.chat}</span>
      </button>

      {/* Chat modal */}
      {showChat && (
        <ZukiChat lang={lang} context={selectedWorld ? WORLDS[selectedWorld].name[lang] : "Mapa principal"}
          onClose={() => setShowChat(false)} />
      )}

      {/* New medal notification */}
      {newMedal && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 pop-in">
          <div className="bg-white rounded-2xl shadow-2xl px-6 py-4 flex items-center gap-3 border-2 border-amber-300">
            <span className="text-4xl">{newMedal.icon}</span>
            <div>
              <p className="text-xs font-bold text-amber-500 uppercase">{t.medals}!</p>
              <p className="font-black text-gray-800">{newMedal.name[lang]}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
